import csv
import sqlite3

con = sqlite3.connect('Cat.db')
cur = con.cursor()

cur.execute('''
    CREATE TABLE IF NOT EXISTS Client(
    id integer primary key autoincrement,
    f text,
    i text,
    o text
    )
    ''')

cur.execute('''
    CREATE TABLE IF NOT EXISTS Postavshiks(
    id integer primary key autoincrement,
    Number integer,
    f text,
    i text,
    o text
    )
    ''')

cur.execute('''
    CREATE TABLE IF NOT EXISTS Tovars(
    id integer primary key autoincrement,
    Name text,
    Postid integer references Postavshiks(id),
    count integer,
    idClient integer references Client(id)
    )
    ''')

cur.execute('''
    CREATE TABLE IF NOT EXISTS Rabotnik(
    id integer primary key autoincrement,
    f text,
    i text,
    o text
    )
    ''')

cur.execute('''
    CREATE TABLE IF NOT EXISTS Postavki(
    id integer primary key autoincrement,
    datetime text,
    Postid integer references Postavshiks(id),
    idTovar integer references Tovars(id),
    count integer,
    idRabotnik integer references Rabotnik(id)
    )
    ''')


#
# with open('Postavki.csv', 'r', newline='', encoding='utf-8') as file:
#     reader = csv.DictReader(file)
#     for row in reader:
#         if row['datetime'] and row['Postid'] and row['idTovar'] and row['count'] and row['idRabotnik']:
#             cur.execute("INSERT INTO Postavki(datetime, Postid, idTovar, count, idRabotnik) VALUES (?, ?, ?, ?, ?)", (row['datetime'], row['Postid'], row['idTovar'], row['count'], row['idRabotnik']))



cur.execute('''SELECT * FROM Client''')
with open('Cat_Export.csv', 'w', newline='') as csvfile:
    csv_writter = csv.writer(csvfile)
    csv_writter.writerow(['id', 'f', 'i', 'o'])
    csv_writter.writerows(cur)

con.commit()
con.close()
